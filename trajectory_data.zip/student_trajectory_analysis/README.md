# Methaniminium trajectory-analysis teaching bundle

This bundle contains a Jupyter notebook and compact data for seven SHARC
trajectories that reached 100 fs.

## Start

From this directory, run:

```bash
jupyter lab methaniminium_trajectory_analysis.ipynb
```

or:

```bash
jupyter notebook methaniminium_trajectory_analysis.ipynb
```

Then run all cells from top to bottom. Required Python packages are listed in
`requirements.txt`.

## Included data

Each `data/TRAJ_*` directory contains:

- `output.xyz`: time-dependent Cartesian coordinates in angstrom;
- `output.lis`: compact SHARC state, energy, spin, and diagnostic data;
- `population_diag.csv`: diagonal-basis quantum populations;
- `population_MCH.csv`: spin-free MCH quantum populations.

The population CSV files were generated from each trajectory's `output.dat`
using SHARC 4 `data_extractor.x -cd -cm -sk`. This keeps the teaching bundle
small while retaining the electronic populations needed by the notebook.

## Scope and limitation

The calculation used 4 singlets and 3 triplets. Triplets have three M_S
components, so SHARC propagates 13 spin components in total. Only seven
trajectories completed 100 fs and are included. The ensemble is suitable for
instruction and exploratory visualization, not converged kinetics.

Methaniminium is CH2NH2+ and contains a C=N bond; there is no C=C bond.
